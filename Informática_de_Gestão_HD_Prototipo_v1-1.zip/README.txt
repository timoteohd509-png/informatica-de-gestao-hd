INFORMÁTICA DE GESTÃO HD — Protótipo v1
Abra index.html no navegador do telemóvel ou computador.
O protótipo inclui: Início, Matemática, Português, Informática, Informática de Gestão,
matérias por tema, exercícios, simulados, revisão rápida e progresso.
Esta é uma versão de demonstração; para publicar como app Android será necessário
empacotar este projeto (por exemplo, numa WebView/Capacitor) e adicionar uma base
de dados/autenticação se forem necessárias contas e sincronização.
