# Assinatura Android — Timóteo HD

Para publicar uma versão de produção, crie uma chave de assinatura e guarde-a num local seguro.

Segredos usados pelo workflow:
- KEYSTORE_BASE64
- KEYSTORE_PASSWORD
- KEY_ALIAS
- KEY_PASSWORD

Sugestão de alias: `timoteo-hd`

NUNCA coloque estes valores diretamente no código ou num ficheiro público.
NUNCA envie a palavra-passe para o ChatGPT.
