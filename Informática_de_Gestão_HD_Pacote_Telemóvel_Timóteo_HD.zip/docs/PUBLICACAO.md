# Publicação — Informática de Gestão HD

Nome da aplicação: Informática de Gestão HD
Publicador: Timóteo HD
ID: ao.timoteohd.informaticagestaohd

Materiais já preparados no pacote anterior:
- ícone
- gráfico promocional
- descrição curta e completa
- checklist de publicação

Antes de publicar:
- testar a aplicação
- criar política de privacidade adequada
- configurar a assinatura
- gerar o AAB de release
- preencher a ficha da loja
- seguir os requisitos atuais da Google Play
